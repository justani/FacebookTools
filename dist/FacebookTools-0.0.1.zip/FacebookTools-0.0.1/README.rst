==============
Facebook Tools
==============

This project provide a simple python module for doing batch tasks on your Facebook profile.
Currently the module provide can be used for leaving mulitple Facebook groups using keywords that occur in the name of those groups.
Typical usage often looks like this:

    ``from facebookTools import groups``

    ``groups.run()``

Prerequisites
=============

You will need to install Chrome WebDriver for this module to work.
Chrome WebDriver can be found and installed from `here <https://sites.google.com/a/chromium.org/chromedriver/downloads>`_.

Installing
==========

For linux
---------

You can extract the tar.gz file and run:

    ``python3 setup.py install``

This will install the module facebookTools.

Then, you can use the module as follows...

#TODO
